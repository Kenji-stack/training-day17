import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Zap } from 'lucide-react';
import FileUpload from './components/FileUpload';
import SlidePreview from './components/SlidePreview';
import { generateSlides } from './services/geminiService';
import { searchImage } from './services/imageService';

function App() {
  const [files, setFiles] = useState([]);
  const [prompt, setPrompt] = useState('');
  const [targetAudience, setTargetAudience] = useState('General');
  const [slideCount, setSlideCount] = useState(5);
  const [isGenerating, setIsGenerating] = useState(false);
  const [slidesData, setSlidesData] = useState(null);
  const [generationStatus, setGenerationStatus] = useState('');

  const handleFilesProcessed = (processedFiles) => {
    setFiles(processedFiles);
  };

  const handleGenerate = async () => {
    if (!prompt) return;

    setIsGenerating(true);
    setGenerationStatus('Analyzing content and generating structure...');

    try {
      // Prepare RAG context
      const ragContext = files.map(f => `File: ${f.name}\nContent: ${f.content}`).join('\n\n');

      // Generate slides structure
      const generatedData = await generateSlides(prompt, ragContext, slideCount, targetAudience);

      setGenerationStatus('Finding perfect visuals...');

      // Enhance with images
      const enhancedSlides = await Promise.all(generatedData.slides.map(async (slide) => {
        if (slide.imageKeyword) {
          const imageUrl = await searchImage(slide.imageKeyword);
          return { ...slide, imageUrl };
        }
        return slide;
      }));

      setSlidesData({ ...generatedData, slides: enhancedSlides });
    } catch (error) {
      console.error("Generation failed:", error);
      alert(`Failed to generate slides. Error: ${error.message || error}`);
    } finally {
      setIsGenerating(false);
      setGenerationStatus('');
    }
  };

  if (slidesData) {
    return (
      <div className="min-h-screen bg-ag-dark text-white">
        <header className="p-6 border-b border-white/10 flex justify-between items-center bg-ag-dark/50 backdrop-blur-md sticky top-0 z-50">
          <div className="flex items-center space-x-2">
            <Zap className="w-6 h-6 text-ag-primary" />
            <span className="font-bold text-xl tracking-tight">AG-SlideGen</span>
          </div>
          <button
            onClick={() => setSlidesData(null)}
            className="text-sm text-white/60 hover:text-white transition-colors"
          >
            Create New
          </button>
        </header>
        <main className="h-[calc(100vh-80px)]">
          <SlidePreview slidesData={slidesData} onEdit={(newSlides) => setSlidesData({ ...slidesData, slides: newSlides })} />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-ag-dark text-white overflow-x-hidden">
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none"></div>

      <header className="p-6 border-b border-white/10 flex justify-between items-center relative z-10">
        <div className="flex items-center space-x-2">
          <Zap className="w-6 h-6 text-ag-primary" />
          <span className="font-bold text-xl tracking-tight">AG-SlideGen</span>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 relative z-10">
        <div className="max-w-3xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-white to-white/50"
            >
              Generate Anti-Gravity Slides
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-xl text-white/60"
            >
              Upload your docs, define your goal, and let AI defy gravity.
            </motion.p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-8"
          >
            {/* File Upload Section */}
            <div className="space-y-4">
              <label className="block text-sm font-medium text-white/80 uppercase tracking-wider">
                1. Knowledge Base (Optional)
              </label>
              <FileUpload onFilesProcessed={handleFilesProcessed} />
            </div>

            {/* Prompt Section */}
            <div className="space-y-4">
              <label className="block text-sm font-medium text-white/80 uppercase tracking-wider">
                2. Presentation Details
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs text-white/50">Topic / Prompt</label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="e.g., Explain Quantum Computing to high school students..."
                    className="w-full h-32 bg-white/5 border border-white/10 rounded-xl p-4 text-white placeholder-white/30 focus:outline-none focus:border-ag-primary focus:ring-1 focus:ring-ag-primary transition-all resize-none"
                  />
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs text-white/50">Target Audience</label>
                    <select
                      value={targetAudience}
                      onChange={(e) => setTargetAudience(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-ag-primary transition-all"
                    >
                      <option value="General">General Audience</option>
                      <option value="Students">Students / Youth</option>
                      <option value="Professionals">Professionals</option>
                      <option value="Investors">Investors</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs text-white/50">Slide Count (Approx)</label>
                    <input
                      type="number"
                      min="3"
                      max="20"
                      value={slideCount}
                      onChange={(e) => setSlideCount(parseInt(e.target.value))}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-white focus:outline-none focus:border-ag-primary transition-all"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt}
              className={`
                w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center space-x-2 transition-all
                ${isGenerating || !prompt
                  ? 'bg-white/10 text-white/30 cursor-not-allowed'
                  : 'bg-gradient-to-r from-ag-primary to-ag-secondary text-white hover:shadow-lg hover:shadow-ag-primary/25 hover:scale-[1.01]'}
              `}
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>{generationStatus}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Generate Presentation</span>
                </>
              )}
            </button>
          </motion.div>
        </div>
      </main>
    </div>
  );
}

export default App;
