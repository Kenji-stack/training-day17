import { GoogleGenerativeAI } from "@google/generative-ai";

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;
const genAI = new GoogleGenerativeAI(API_KEY);

const model = genAI.getGenerativeModel({
  model: "gemini-2.0-flash-exp",
  generationConfig: {
    responseMimeType: "application/json",
  }
});

export const generateSlides = async (prompt, ragContext, slideCount = 5, targetAudience = "General") => {
  const systemPrompt = `
    You are an expert presentation designer for the "Anti-Gravity" brand. 
    Your goal is to create engaging, high-quality presentation slides based on the provided content and user prompt.
    
    Target Audience: ${targetAudience}
    Estimated Slide Count: ${slideCount}
    
    Output Format: JSON
    The output must be a valid JSON object with the following structure:
    {
      "title": "Presentation Title",
      "slides": [
        {
          "type": "TITLE" | "CONTENT_LEFT" | "CONTENT_RIGHT" | "BULLETS" | "QUOTE",
          "title": "Slide Title",
          "content": "Main text content for the slide. Keep it concise and impactful.",
          "imageKeyword": "A specific keyword or short phrase to search for a relevant background or illustration image."
        }
      ]
    }
    
    Design Guidelines:
    - Use "Anti-Gravity" style: futuristic, bold, dynamic.
    - Content should be educational but exciting.
    - For "TITLE" slides, content can be a subtitle.
    - For "CONTENT" slides, use bullet points or short paragraphs.
    
    RAG Context (Use this information to generate the content):
    ${ragContext}
  `;

  const userMessage = `Generate a presentation about: ${prompt}`;

  try {
    const result = await model.generateContent([systemPrompt, userMessage]);
    const response = await result.response;
    const text = response.text();
    return JSON.parse(text);
  } catch (error) {
    console.error("Error generating slides:", error);
    throw error;
  }
};
