import PptxGenJS from "pptxgenjs";

export const exportToPPTX = async (slidesData) => {
    const pptx = new PptxGenJS();

    // Set Presentation Metadata
    pptx.title = slidesData.title;
    pptx.subject = "Anti-Gravity Presentation";
    pptx.author = "AG-SlideGen";

    // Define Master Slide (Theme)
    pptx.defineSlideMaster({
        title: "AG_MASTER",
        background: { color: "0F172A" }, // ag-dark
        objects: [
            { rect: { x: 0, y: 0, w: "100%", h: "100%", fill: { color: "0F172A" } } }
        ]
    });

    // Generate Slides
    for (const slide of slidesData.slides) {
        const pptSlide = pptx.addSlide({ masterName: "AG_MASTER" });

        // Add Background Image if available
        if (slide.imageUrl) {
            // Note: pptxgenjs handles image URLs, but CORS might be an issue.
            // We'll try to add it, if it fails, it might just be blank.
            try {
                pptSlide.background = { path: slide.imageUrl };
                // Add a dark overlay for readability
                pptSlide.addShape(pptx.ShapeType.rect, {
                    x: 0, y: 0, w: "100%", h: "100%",
                    fill: { color: "000000", transparency: 60 }
                });
            } catch (e) {
                console.warn("Could not add background image:", e);
            }
        }

        // Add Content based on type
        switch (slide.type) {
            case 'TITLE':
                pptSlide.addText(slide.title, {
                    x: 0.5, y: 2.5, w: 9, h: 1.5,
                    fontSize: 44, color: "FFFFFF", bold: true, align: "center", fontFace: "Arial"
                });
                pptSlide.addText(slide.content, {
                    x: 1, y: 4.5, w: 8, h: 1,
                    fontSize: 24, color: "CCCCCC", align: "center", fontFace: "Arial"
                });
                break;

            case 'CONTENT_LEFT':
                pptSlide.addText(slide.title, {
                    x: 0.5, y: 0.5, w: 4.5, h: 1,
                    fontSize: 32, color: "8B5CF6", bold: true, fontFace: "Arial" // ag-primary
                });
                pptSlide.addText(slide.content, {
                    x: 0.5, y: 1.5, w: 4.5, h: 5,
                    fontSize: 18, color: "FFFFFF", fontFace: "Arial", wrap: true
                });
                // Image is handled by background or we could add it as a shape on the right
                break;

            default:
                pptSlide.addText(slide.title, {
                    x: 0.5, y: 0.5, w: 9, h: 1,
                    fontSize: 32, color: "8B5CF6", bold: true, fontFace: "Arial"
                });
                pptSlide.addText(slide.content, {
                    x: 0.5, y: 1.5, w: 9, h: 5,
                    fontSize: 18, color: "FFFFFF", fontFace: "Arial", wrap: true
                });
                break;
        }
    }

    // Save the file
    await pptx.writeFile({ fileName: `${slidesData.title.replace(/[^a-z0-9]/gi, '_')}.pptx` });
};
