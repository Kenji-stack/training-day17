import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Download, Edit2, Save } from 'lucide-react';

import { exportToPPTX } from '../services/exportService';

const SlidePreview = ({ slidesData, onEdit }) => {
    const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
    const [isEditing, setIsEditing] = useState(false);
    const [editedSlides, setEditedSlides] = useState(slidesData.slides);
    const [isExporting, setIsExporting] = useState(false);

    useEffect(() => {
        setEditedSlides(slidesData.slides);
    }, [slidesData]);

    const currentSlide = editedSlides[currentSlideIndex];

    const nextSlide = () => {
        if (currentSlideIndex < editedSlides.length - 1) {
            setCurrentSlideIndex(prev => prev + 1);
        }
    };

    const prevSlide = () => {
        if (currentSlideIndex > 0) {
            setCurrentSlideIndex(prev => prev - 1);
        }
    };

    const handleContentChange = (field, value) => {
        const newSlides = [...editedSlides];
        newSlides[currentSlideIndex] = {
            ...newSlides[currentSlideIndex],
            [field]: value
        };
        setEditedSlides(newSlides);
    };

    const saveChanges = () => {
        onEdit(editedSlides);
        setIsEditing(false);
    };

    const handleExport = async () => {
        setIsExporting(true);
        try {
            await exportToPPTX({ ...slidesData, slides: editedSlides });
        } catch (error) {
            console.error("Export failed:", error);
            alert("Failed to export presentation.");
        } finally {
            setIsExporting(false);
        }
    };

    const renderSlideContent = (slide) => {
        const commonClasses = "h-full flex flex-col justify-center p-12 text-white relative overflow-hidden";
        const bgImageStyle = slide.imageUrl ? { backgroundImage: `url(${slide.imageUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {};
        const overlay = <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-0" />;

        switch (slide.type) {
            case 'TITLE':
                return (
                    <div className={`${commonClasses} items-center text-center`} style={bgImageStyle}>
                        {slide.imageUrl && overlay}
                        <div className="z-10 relative max-w-4xl">
                            {isEditing ? (
                                <input
                                    value={slide.title}
                                    onChange={(e) => handleContentChange('title', e.target.value)}
                                    className="text-6xl font-black bg-transparent border-b border-white/20 w-full text-center focus:outline-none focus:border-ag-primary mb-6"
                                />
                            ) : (
                                <h1 className="text-6xl font-black mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-white/80">
                                    {slide.title}
                                </h1>
                            )}
                            {isEditing ? (
                                <textarea
                                    value={slide.content}
                                    onChange={(e) => handleContentChange('content', e.target.value)}
                                    className="text-2xl text-white/80 bg-transparent border border-white/20 w-full text-center focus:outline-none focus:border-ag-primary p-2 rounded"
                                />
                            ) : (
                                <p className="text-2xl text-white/80 font-light">{slide.content}</p>
                            )}
                        </div>
                    </div>
                );

            case 'CONTENT_LEFT':
                return (
                    <div className="h-full flex relative bg-ag-surface">
                        <div className="w-1/2 p-12 flex flex-col justify-center z-10">
                            {isEditing ? (
                                <input
                                    value={slide.title}
                                    onChange={(e) => handleContentChange('title', e.target.value)}
                                    className="text-4xl font-bold mb-8 bg-transparent border-b border-white/20 w-full focus:outline-none focus:border-ag-primary"
                                />
                            ) : (
                                <h2 className="text-4xl font-bold mb-8 text-ag-primary">{slide.title}</h2>
                            )}
                            {isEditing ? (
                                <textarea
                                    value={slide.content}
                                    onChange={(e) => handleContentChange('content', e.target.value)}
                                    className="text-lg leading-relaxed text-white/90 bg-transparent border border-white/20 w-full h-64 focus:outline-none focus:border-ag-primary p-2 rounded resize-none"
                                />
                            ) : (
                                <div className="text-lg leading-relaxed text-white/90 whitespace-pre-wrap">
                                    {slide.content}
                                </div>
                            )}
                        </div>
                        <div className="w-1/2 h-full absolute right-0 top-0 bottom-0" style={bgImageStyle}>
                            <div className="absolute inset-0 bg-gradient-to-r from-ag-surface to-transparent" />
                        </div>
                    </div>
                );

            // Add other cases (CONTENT_RIGHT, BULLETS, QUOTE) similarly...
            // For brevity, I'll use a default layout for others for now, but in a full app I'd implement all.
            default:
                return (
                    <div className={`${commonClasses}`} style={bgImageStyle}>
                        {slide.imageUrl && overlay}
                        <div className="z-10 relative max-w-4xl mx-auto">
                            <h2 className="text-4xl font-bold mb-8 text-ag-primary">{slide.title}</h2>
                            <div className="text-lg leading-relaxed text-white/90 whitespace-pre-wrap">
                                {slide.content}
                            </div>
                        </div>
                    </div>
                );
        }
    };

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-black/90 p-8">
            <div className="w-full max-w-6xl aspect-video bg-ag-surface rounded-xl shadow-2xl overflow-hidden relative border border-white/10">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={currentSlideIndex}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.3 }}
                        className="w-full h-full"
                    >
                        {renderSlideContent(currentSlide)}
                    </motion.div>
                </AnimatePresence>

                {/* Navigation Controls */}
                <div className="absolute bottom-6 right-6 flex space-x-4 z-20">
                    <button
                        onClick={prevSlide}
                        disabled={currentSlideIndex === 0}
                        className="p-3 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-30 backdrop-blur-md transition-all"
                    >
                        <ChevronLeft className="w-6 h-6 text-white" />
                    </button>
                    <span className="flex items-center text-white/50 font-mono">
                        {currentSlideIndex + 1} / {editedSlides.length}
                    </span>
                    <button
                        onClick={nextSlide}
                        disabled={currentSlideIndex === editedSlides.length - 1}
                        className="p-3 rounded-full bg-white/10 hover:bg-white/20 disabled:opacity-30 backdrop-blur-md transition-all"
                    >
                        <ChevronRight className="w-6 h-6 text-white" />
                    </button>
                </div>

                {/* Edit Controls */}
                <div className="absolute top-6 right-6 flex space-x-4 z-20">
                    {isEditing ? (
                        <button
                            onClick={saveChanges}
                            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 backdrop-blur-md transition-all"
                        >
                            <Save className="w-4 h-4" />
                            <span>Save</span>
                        </button>
                    ) : (
                        <button
                            onClick={() => setIsEditing(true)}
                            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-white/10 text-white hover:bg-white/20 backdrop-blur-md transition-all"
                        >
                            <Edit2 className="w-4 h-4" />
                            <span>Edit</span>
                        </button>
                    )}
                </div>
            </div>

            <div className="mt-8 flex space-x-4">
                <button
                    onClick={handleExport}
                    disabled={isExporting}
                    className="flex items-center space-x-2 px-6 py-3 rounded-lg bg-ag-primary hover:bg-ag-primary/80 text-white font-semibold transition-all shadow-lg shadow-ag-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isExporting ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                        <Download className="w-5 h-5" />
                    )}
                    <span>{isExporting ? 'Exporting...' : 'Export to PowerPoint'}</span>
                </button>
            </div>
        </div>
    );
};

export default SlidePreview;
