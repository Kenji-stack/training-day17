const API_KEY = import.meta.env.VITE_GOOGLE_SEARCH_API_KEY;
const CX = import.meta.env.VITE_GOOGLE_SEARCH_ENGINE_ID;

export const searchImage = async (query) => {
    // If no API key, return a placeholder immediately
    if (!API_KEY || !CX) {
        console.warn("Google Search API key or CX not found. Returning placeholder.");
        return `https://placehold.co/1280x720/1e293b/white?text=${encodeURIComponent(query)}`;
    }

    const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(query)}&cx=${CX}&searchType=image&key=${API_KEY}&num=1&safe=active&imgSize=large`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        if (data.items && data.items.length > 0) {
            return data.items[0].link;
        }
        // Fallback if no results
        return `https://placehold.co/1280x720/1e293b/white?text=${encodeURIComponent(query)}`;
    } catch (error) {
        console.error("Error searching image:", error);
        return `https://placehold.co/1280x720/1e293b/white?text=${encodeURIComponent(query)}`;
    }
};
