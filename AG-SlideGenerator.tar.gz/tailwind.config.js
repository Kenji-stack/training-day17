/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                'ag-primary': '#8b5cf6', // Violet 500
                'ag-secondary': '#ec4899', // Pink 500
                'ag-dark': '#0f172a', // Slate 900
                'ag-surface': '#1e293b', // Slate 800
            },
            fontFamily: {
                sans: ['Inter', 'sans-serif'],
            },
        },
    },
    plugins: [],
}
