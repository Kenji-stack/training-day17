import React, { useState } from 'react';
import { Upload, FileText, X, CheckCircle } from 'lucide-react';
import { extractTextFromFile } from '../services/ragService';
import { motion, AnimatePresence } from 'framer-motion';

const FileUpload = ({ onFilesProcessed }) => {
    const [isDragging, setIsDragging] = useState(false);
    const [files, setFiles] = useState([]);
    const [processing, setProcessing] = useState(false);

    const handleDragOver = (e) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = () => {
        setIsDragging(false);
    };

    const processFiles = async (fileList) => {
        setProcessing(true);
        const newFiles = [];

        for (const file of fileList) {
            try {
                const text = await extractTextFromFile(file);
                newFiles.push({
                    name: file.name,
                    type: file.type,
                    content: text,
                    status: 'success'
                });
            } catch (error) {
                console.error("Error processing file:", file.name, error);
                newFiles.push({
                    name: file.name,
                    status: 'error',
                    error: error.message
                });
            }
        }

        setFiles(prev => [...prev, ...newFiles]);
        // Notify parent about successful files
        const successfulFiles = newFiles.filter(f => f.status === 'success');
        if (successfulFiles.length > 0) {
            onFilesProcessed(successfulFiles);
        }
        setProcessing(false);
    };

    const handleDrop = async (e) => {
        e.preventDefault();
        setIsDragging(false);
        const droppedFiles = Array.from(e.dataTransfer.files);
        await processFiles(droppedFiles);
    };

    const handleFileSelect = async (e) => {
        const selectedFiles = Array.from(e.target.files);
        await processFiles(selectedFiles);
    };

    const removeFile = (index) => {
        setFiles(prev => prev.filter((_, i) => i !== index));
        // Note: This doesn't remove from parent state currently.
        // Ideally we'd have a callback for removal too.
    };

    return (
        <div className="w-full max-w-2xl mx-auto">
            <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`
          relative border-2 border-dashed rounded-xl p-8 transition-all duration-300
          ${isDragging
                        ? 'border-ag-primary bg-ag-primary/10 scale-[1.02]'
                        : 'border-white/20 hover:border-ag-primary/50 hover:bg-white/5'}
        `}
            >
                <input
                    type="file"
                    multiple
                    onChange={handleFileSelect}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    accept=".txt,.md,.pdf"
                />

                <div className="flex flex-col items-center justify-center text-center space-y-4">
                    <div className={`p-4 rounded-full bg-white/5 ${isDragging ? 'animate-bounce' : ''}`}>
                        <Upload className="w-8 h-8 text-ag-primary" />
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-white">
                            Drop files here or click to upload
                        </h3>
                        <p className="text-sm text-white/50 mt-1">
                            Support for PDF, Markdown, and Text files
                        </p>
                    </div>
                </div>
            </div>

            <div className="mt-6 space-y-3">
                <AnimatePresence>
                    {files.map((file, index) => (
                        <motion.div
                            key={`${file.name}-${index}`}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, x: -10 }}
                            className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10"
                        >
                            <div className="flex items-center space-x-3">
                                <FileText className="w-5 h-5 text-ag-secondary" />
                                <span className="text-sm text-white/90">{file.name}</span>
                            </div>
                            <div className="flex items-center space-x-3">
                                {file.status === 'success' ? (
                                    <CheckCircle className="w-5 h-5 text-green-500" />
                                ) : (
                                    <span className="text-xs text-red-400">{file.error}</span>
                                )}
                                <button
                                    onClick={() => removeFile(index)}
                                    className="p-1 hover:bg-white/10 rounded-full transition-colors"
                                >
                                    <X className="w-4 h-4 text-white/50" />
                                </button>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
        </div>
    );
};

export default FileUpload;
