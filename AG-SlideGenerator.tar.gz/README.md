# Anti-Gravity Style Slide Generator

AI駆動のプレゼンテーションスライド生成Webアプリケーション

## 概要

Anti-Gravity Style Slide Generatorは、Gemini APIを使用してRAG（Retrieval-Augmented Generation）技術に基づいた高品質なプレゼンテーションスライドを自動生成するWebアプリケーションです。

## 主な機能

- 📄 **ファイルアップロード**: PDF、Markdown、テキストファイルからRAG知識ベースを構築
- 🤖 **AI生成**: Gemini APIによる自動スライド構成とコンテンツ生成
- 🖼️ **画像検索**: Google Custom Search APIによる関連画像の自動選択
- ✏️ **編集機能**: 生成後のスライドをリアルタイムで編集
- 📊 **PowerPointエクスポート**: .pptx形式でのダウンロード
- 🎨 **Anti-Gravityデザイン**: 未来的でダイナミックなUIデザイン

## 技術スタック

- **フロントエンド**: React 18 + Vite 7
- **スタイリング**: Tailwind CSS v4
- **アニメーション**: Framer Motion
- **AI**: Google Gemini API (gemini-2.0-flash-exp)
- **画像検索**: Google Custom Search API
- **データベース**: Firebase Firestore
- **認証**: Firebase Authentication
- **エクスポート**: PptxGenJS

## セットアップ

### 前提条件

- Node.js 18以上
- npm または yarn
- Gemini APIキー
- Google Custom Search APIキー（オプション）
- Firebaseプロジェクト（オプション）

### インストール

1. リポジトリをクローン

```bash
git clone <repository-url>
cd SlideGenerator
```

2. 依存関係をインストール

```bash
npm install
```

3. 環境変数を設定

`.env.local`ファイルを作成し、以下の内容を設定：

```env
VITE_GEMINI_API_KEY=your_gemini_api_key_here
VITE_GOOGLE_SEARCH_API_KEY=your_google_search_api_key_here
VITE_GOOGLE_SEARCH_ENGINE_ID=your_search_engine_id_here
VITE_FIREBASE_API_KEY=your_firebase_api_key_here
VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

4. 開発サーバーを起動

```bash
npm run dev
```

アプリケーションは http://localhost:5173 で起動します。

## ビルド

本番環境用にビルド：

```bash
npm run build
```

ビルドされたファイルは`dist/`ディレクトリに出力されます。

## 使い方

1. **ファイルアップロード**: PDF、Markdown、またはテキストファイルをドラッグ&ドロップ
2. **プロンプト入力**: 生成したいプレゼンテーションの内容を記述
3. **設定**: ターゲットオーディエンスとスライド枚数を選択
4. **生成**: 「Generate Presentation」ボタンをクリック
5. **編集**: 生成されたスライドを必要に応じて編集
6. **エクスポート**: PowerPoint形式でダウンロード

## プロジェクト構造

```
SlideGenerator/
├── src/
│   ├── components/          # Reactコンポーネント
│   │   ├── FileUpload.jsx
│   │   └── SlidePreview.jsx
│   ├── services/            # APIサービス層
│   │   ├── ragService.js
│   │   ├── geminiService.js
│   │   ├── imageService.js
│   │   └── exportService.js
│   ├── lib/                 # ライブラリ設定
│   │   └── firebase.js
│   ├── App.jsx              # メインアプリケーション
│   ├── index.css            # グローバルスタイル
│   └── main.jsx             # エントリーポイント
├── public/                  # 静的ファイル
├── .env.example             # 環境変数テンプレート
├── package.json
├── vite.config.js
└── tailwind.config.js
```

## APIキーの取得

### Gemini API

1. [Google AI Studio](https://aistudio.google.com/) にアクセス
2. APIキーを作成
3. `.env.local`の`VITE_GEMINI_API_KEY`に設定

### Google Custom Search API（オプション）

1. [Google Cloud Console](https://console.cloud.google.com/) でプロジェクトを作成
2. Custom Search APIを有効化
3. APIキーを作成
4. [Programmable Search Engine](https://programmablesearchengine.google.com/) でカスタム検索エンジンを作成
5. `.env.local`に設定

## ライセンス

MIT

## 作成者

Anti-Gravity Development Team
